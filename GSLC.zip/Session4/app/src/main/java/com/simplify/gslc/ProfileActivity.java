package com.simplify.gslc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ProfileActivity extends AppCompatActivity {
    GridView listView;
    int[] imageList = {R.drawable.ic_house, R.drawable.ic_calendar, R.drawable.ic_book
            , R.drawable.ic_wallet, R.drawable.ic_settings, R.drawable.ic_exit_to_app};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String binusian = intent.getStringExtra("binusian");
        String role = intent.getStringExtra("role");
        TextView nameText = findViewById(R.id.name_text);
        TextView binusianText = findViewById(R.id.role_id_text);
        nameText.setText(name);
        binusianText.setText(String.format("%s - %s", binusian, role));
        listView = findViewById(R.id.grid_view);

        CustomAdapter adapter = new CustomAdapter(this, imageList);
        listView.setAdapter(adapter);


    }
}