package com.simplify.gslc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        TextInputEditText nameText = findViewById(R.id.name_edittext);
        TextInputEditText binusianText = findViewById(R.id.binusian_edittext);
        AutoCompleteTextView roleText = findViewById(R.id.role_spinner);
        MaterialButton register = findViewById(R.id.register_button);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.role_list, com.google.android.material.R.layout.support_simple_spinner_dropdown_item);

        roleText.setAdapter(adapter);

        roleText.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = parent.getItemAtPosition(position).toString();
            Toast.makeText(MainActivity.this, "Selected: " + selectedItem, Toast.LENGTH_SHORT).show();
        });

        register.setOnClickListener(v -> {
            String name = nameText.getText() != null ? nameText.getText().toString().trim() : "";
            String binusian = binusianText.getText() != null ? binusianText.getText().toString().trim() : "";
            String role = roleText.getText() != null ? roleText.getText().toString().trim() : "";
            if (name.isEmpty()) {
                nameText.setError("Name cannot be empty");
            } else if (binusian.isEmpty()) {
                binusianText.setError("Binusian ID cannot be empty");
            } else if (role.isEmpty() ||(!role.equals("Student") && !role.equals("Lecture") && !role.equals("Admin"))) {
                roleText.setError("Role cannot be empty or invalid");
            } else {
                Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                intent.putExtra("name", name);
                intent.putExtra("binusian", binusian);
                intent.putExtra("role", role);
                startActivity(intent);
            }
        });

    }
}