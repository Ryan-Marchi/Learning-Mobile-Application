package com.simplify.session5;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    List<ContactData> contactData;
    Random rand = new Random();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        RecyclerView mainContactRV = findViewById(R.id.mainContactRV);

        prepareData();

        mainContactRV.setLayoutManager(new LinearLayoutManager(this));
        mainContactRV.setAdapter(new ContactAdapter(contactData));

    }

    private void prepareData() {
        contactData = new ArrayList<>();
        for (int i = 0; i < rand.nextInt(30) + 10; i++) {
            String[] firstNames = {"John", "Jane", "Bob", "Alice", "Mike", "Sarah", "Steve", "Emily", "Tom", "Alex", "Clark"};
            String[] lastNames = {"Doe", "Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Wilson", "Moore"};
            String firstName = firstNames[(rand.nextInt(firstNames.length))];
            String lastName = lastNames[(rand.nextInt(lastNames.length))];
            String number = createPhoneNumber();
            contactData.add(new ContactData(firstName + " " + lastName, number));
        }
    }

    private String createPhoneNumber() {
        StringBuilder number = new StringBuilder();
        number.append("+628");
        for (int i = 0; i < rand.nextInt(2) + 9; i++) {
            number.append(rand.nextInt(9) + 1);
        }
        return number.toString();
    }
}