package com.simplify.session5;

public class ContactData {
    private final String name;
    private final String phoneNumber;

    public ContactData(String name, String phoneNumber) {
        this.name = name;
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getName() {
        return name;
    }
}
