package com.simplify.session5;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ContactHolder> {
    private Context activityContext;
    private List<ContactData> contactDataList;

    public ContactAdapter(List<ContactData> contactDataList) {
        this.contactDataList = contactDataList;
    }

    @NonNull
    @Override
    public ContactAdapter.ContactHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        activityContext = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(activityContext);
        View contactView = inflater.inflate(R.layout.item_contact, parent, false);
        return new ContactHolder(contactView);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactAdapter.ContactHolder holder, int position) {
        String name = contactDataList.get(position).getName();
        String phoneNumber = contactDataList.get(position).getPhoneNumber();

        holder.itemName.setText(name);
        holder.itemNumberTV.setText(phoneNumber);

        holder.itemContainer.setOnClickListener(v -> {
            Intent phoneIntent = new Intent(Intent.ACTION_DIAL);
            phoneIntent.setData(Uri.parse("tel:" + phoneNumber));
            activityContext.startActivity(phoneIntent);
        });
    }

    @Override
    public int getItemCount() {
        return contactDataList.size();
    }

    public static class ContactHolder extends RecyclerView.ViewHolder {
        TextView itemName;
        TextView itemNumberTV;
        LinearLayout itemContainer;

        public ContactHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemNameTV);
            itemNumberTV = itemView.findViewById(R.id.itemNumberTV);
            itemContainer = itemView.findViewById(R.id.itemContainer);
        }
    }
}
